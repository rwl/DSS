package cern.colt.function.tfcomplex;

public interface FComplexFComplexProcedure {
    abstract public boolean apply(float[] x, float[] y);
}
