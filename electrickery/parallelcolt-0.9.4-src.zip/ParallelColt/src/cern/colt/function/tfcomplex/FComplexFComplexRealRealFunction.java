package cern.colt.function.tfcomplex;

public interface FComplexFComplexRealRealFunction {
    abstract public float apply(float[] x, float[] y, float tol);
}
