package cern.colt.function.tdcomplex;

public interface DComplexDComplexProcedure {
    abstract public boolean apply(double[] x, double[] y);
}
